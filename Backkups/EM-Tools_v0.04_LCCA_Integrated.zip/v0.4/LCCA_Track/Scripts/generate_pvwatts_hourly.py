import pandas as pd
import numpy as np

def generate_pvwatts_hourly(system_size_kw, tilt, azimuth, losses, location):
    """
    Mockup PVWatts-like hourly generation model.
    """
    hours = 8760
    base_profile = np.clip(np.sin(np.linspace(0, 2*np.pi, hours)) * 5, 0, None)
    generation = system_size_kw * base_profile * (1 - losses/100)

    df = pd.DataFrame({
        'Hour': range(1, hours+1),
        'Generation_kWh': generation
    })
    return df
