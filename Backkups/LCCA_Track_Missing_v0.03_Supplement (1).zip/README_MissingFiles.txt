This folder contains placeholder versions of missing scripts from LCCA Track v0.03.

Missing or unconfirmed in transfer:
- generate_pvwatts_hourly.py
- format_lcca_inputs.py

These scripts must be populated with final logic during v0.04 development.
