import pandas as pd

def format_inputs(ab_hourly_csv, ap_hourly_csv, pv_csv):
    """
    Combines AB/AP HourlyResults and PVWatts into one normalized input set for LCCA analysis.
    """
    ab = pd.read_csv(ab_hourly_csv)
    ap = pd.read_csv(ap_hourly_csv)
    pv = pd.read_csv(pv_csv)

    ab['Model'] = 'AB'
    ap['Model'] = 'AP'
    pv['Model'] = 'PV'

    return pd.concat([ab, ap, pv], ignore_index=True)
