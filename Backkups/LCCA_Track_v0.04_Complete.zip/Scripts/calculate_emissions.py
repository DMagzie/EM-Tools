import pandas as pd

def calculate_emissions(hourly_df, grid_emission_factor):
    """
    Calculates hourly emissions in kgCO2 based on kWh and emission factor (kgCO2/kWh).
    """
    hourly_df['kgCO2'] = hourly_df['Generation_kWh'] * grid_emission_factor
    return hourly_df
