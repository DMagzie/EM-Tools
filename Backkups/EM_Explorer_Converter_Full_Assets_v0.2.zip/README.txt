
# EM Explorer & Converter Project Structure

- source_code/
  Contains modular Python scripts for each tool component.
- mappings/
  Includes JSON dictionaries for mapping CBECC terms to IESVE, ASHRAE, and ECON-1 categories.
- test_files/
  Folder to place example XML and simulation output files.
- outputs/
  Place IDF, INP, ECON-1 reports, and comparison tables here.

## GitHub & .env Notes
- Recommended `.env` variables:
  OPENAI_API_KEY=your_key_here
  DROPBOX_TOKEN=your_token_here
  GITHUB_PAT=your_github_token

- Automation scripts can be built to auto-upload output files to GitHub or Dropbox.
