def calculate_room_loads(rooms):
    return [{ "room": r["name"], "cool": r["area"] * 12, "heat": r["area"] * 10 } for r in rooms]