def compare_baselines(t24, ashrae):
    # Compute difference for each end use
    return {k: t24.get(k, 0) - ashrae.get(k, 0) for k in t24}