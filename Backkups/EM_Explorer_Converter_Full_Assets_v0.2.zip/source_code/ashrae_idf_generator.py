def generate_idf_from_baseline(xml_file):
    # Stub logic to generate IDF lines
    return ["Version,9.6;", "Building,MyASHRAEBuilding;"]

def export_idf(lines, output_path):
    with open(output_path, "w") as f:
        for line in lines:
            f.write(line + "\n")