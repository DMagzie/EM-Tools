def summarize_energy_use(energy_data):
    # Aggregate site energy by end use
    return {use: sum(values) for use, values in energy_data.items()}

def format_report(summary):
    return "\n".join([f"{k}: {v:.1f}" for k, v in summary.items()])