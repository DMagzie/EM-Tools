from source_code.dual_baseline_comparison import compare

def test_compare():
    t24 = {'Heating': 10000, 'Cooling': 8000}
    ashrae = {'Heating': 9500, 'Cooling': 9200}
    result = compare(t24, ashrae)
    assert result['Heating'] == 500
    assert result['Cooling'] == -1200

if __name__ == '__main__':
    test_compare()
    print("All tests passed.")