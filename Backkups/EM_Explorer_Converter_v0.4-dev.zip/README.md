# v0.4-dev – Dual Baseline Comparison Tool

This development folder includes logic and test cases for the Dual Baseline Comparison Tool.

## Modules

- `dual_baseline_comparison.py`: Compares Title 24 and ASHRAE 90.1 simulation outputs.
- `test_dual_baseline_comparison.py`: Unit test validating baseline comparison logic.

## Next Steps

- Expand test coverage with real simulation output files.
- Submit finalized version to `v0.4/` for production tagging.