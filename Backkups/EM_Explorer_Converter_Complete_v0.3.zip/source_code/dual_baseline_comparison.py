def compare(t24, ashrae):
    return {k: t24.get(k, 0) - ashrae.get(k, 0) for k in set(t24) | set(ashrae)}

def write_comparison(result, path):
    with open(path, "w") as f:
        for k, v in result.items():
            f.write(f"{k},{v}\n")