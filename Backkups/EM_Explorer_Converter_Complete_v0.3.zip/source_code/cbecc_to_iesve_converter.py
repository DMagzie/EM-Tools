import xml.etree.ElementTree as ET

def parse_zones(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    return [zone.attrib['Name'] for zone in root.findall(".//Zone")]

def convert_to_iesve(zones):
    return "\n".join([f"Zone,{zone},Auto;" for zone in zones])

def main(xml_path):
    zones = parse_zones(xml_path)
    iesve_data = convert_to_iesve(zones)
    return iesve_data