def generate_report(energy_data):
    lines = [f"{end_use}: {value} kBtu" for end_use, value in energy_data.items()]
    return "\n".join(lines)

def save_report(report_str, path):
    with open(path, "w") as f:
        f.write(report_str)