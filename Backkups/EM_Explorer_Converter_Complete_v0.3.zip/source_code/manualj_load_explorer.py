def calculate_loads(rooms):
    return [{"room": r["name"], "cooling_btuh": r["area"] * 15, "heating_btuh": r["area"] * 10} for r in rooms]

def summarize(loads):
    return {
        "total_cooling": sum(r["cooling_btuh"] for r in loads),
        "total_heating": sum(r["heating_btuh"] for r in loads)
    }