def generate_idf(zones):
    header = ["Version,9.6;", "Building,ASHRAE_Generated;"]
    zone_defs = [f"Zone,{zone};" for zone in zones]
    return "\n".join(header + zone_defs)

def write_idf(content, output_path):
    with open(output_path, "w") as f:
        f.write(content)