
import dropbox

def upload_file(file_path, dropbox_path, token):
    dbx = dropbox.Dropbox(token)
    with open(file_path, "rb") as f:
        dbx.files_upload(f.read(), dropbox_path, mode=dropbox.files.WriteMode.overwrite)
