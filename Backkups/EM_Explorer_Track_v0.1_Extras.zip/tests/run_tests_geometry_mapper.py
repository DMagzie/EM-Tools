# test script for Geometry Mapper
print('Running Geometry Mapper tests...')