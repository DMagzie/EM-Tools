# test script for Manual J Viewer
print('Running Manual J Viewer tests...')